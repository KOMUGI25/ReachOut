package reachout.ui;

import reachout.dao.RequestDAO;
import reachout.model.Request;
import reachout.service.MatchingService;
import reachout.service.ResourceNotFoundException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class RequestPanel extends JPanel {

    private final RequestDAO requestDAO = new RequestDAO();
    private final MatchingService matchingService = new MatchingService();
    private DefaultTableModel tableModel;

    public RequestPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(buildForm(), BorderLayout.NORTH);
        add(buildTable(), BorderLayout.CENTER);

        refreshTable();
    }

    private JPanel buildForm() {
        JPanel section = new JPanel(new BorderLayout());
        section.setBorder(BorderFactory.createTitledBorder("Raise a Request"));

        JPanel form = new JPanel(new GridLayout(1, 7, 5, 5));
        JTextField requesterField = new JTextField();
        JTextField itemField = new JTextField();
        JTextField locationField = new JTextField();
        JButton raiseButton = new JButton("Raise & Match");

        form.add(new JLabel("Requester:"));
        form.add(requesterField);
        form.add(new JLabel("Item Needed:"));
        form.add(itemField);
        form.add(new JLabel("Location:"));
        form.add(locationField);
        form.add(raiseButton);

        raiseButton.addActionListener(e -> {
            String requester = requesterField.getText().trim();
            String item = itemField.getText().trim();
            String location = locationField.getText().trim();

            if (requester.isEmpty() || item.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Missing info", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                int requestId = requestDAO.addRequest(new Request(0, requester, item, location, "PENDING", null, null));

                Request newRequest = new Request(requestId, requester, item, location, "PENDING", null, null);
                try {
                    matchingService.matchRequest(newRequest);
                    JOptionPane.showMessageDialog(this, "Request raised and matched successfully!");
                } catch (ResourceNotFoundException nfEx) {
                    JOptionPane.showMessageDialog(this, "Request raised, but no match yet: " + nfEx.getMessage(),
                            "No Match Found", JOptionPane.WARNING_MESSAGE);
                }

                requesterField.setText("");
                itemField.setText("");
                locationField.setText("");
                refreshTable();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        section.add(form, BorderLayout.NORTH);
        return section;
    }

    private JScrollPane buildTable() {
        tableModel = new DefaultTableModel(
                new String[]{"ID", "Requester", "Item", "Location", "Status", "Matched Resource", "Assigned Volunteer"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        JTable table = new JTable(tableModel);
        return new JScrollPane(table);
    }

    private void refreshTable() {
        try {
            tableModel.setRowCount(0);
            List<Request> requests = requestDAO.getAllRequests();
            for (Request r : requests) {
                tableModel.addRow(new Object[]{
                        r.getRequestId(), r.getRequesterName(), r.getItemNeeded(), r.getLocation(),
                        r.getStatus(),
                        r.getMatchedResourceId() != null ? r.getMatchedResourceId() : "-",
                        r.getAssignedVolunteerId() != null ? r.getAssignedVolunteerId() : "-"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load requests: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}