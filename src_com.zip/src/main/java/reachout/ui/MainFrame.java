package reachout.ui;

import javax.swing.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("ReachOut - Community Emergency Resource Network");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        // Placeholder tabs for now — we'll replace each JLabel with the real
        // panel (DonorPanel, RequestPanel, TrackingPanel) in the next phases.
        tabs.addTab("Donors", new DonorPanel());
        tabs.addTab("Requests", new RequestPanel());
        tabs.addTab("Tracking", new TrackingPanel());
        add(tabs);
    }
}