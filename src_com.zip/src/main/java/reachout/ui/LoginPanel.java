package reachout.ui;

import reachout.dao.UserDAO;
import reachout.model.User;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class LoginPanel extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginPanel() {
        setTitle("ReachOut - Login");
        setSize(350, 200);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);   // centers the window on screen

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        panel.add(new JLabel());   // empty cell for spacing
        panel.add(loginButton);

        add(panel);

        loginButton.addActionListener(e -> attemptLogin());
    }

    private void attemptLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        try {
            UserDAO userDAO = new UserDAO();
            User user = userDAO.validateLogin(username, password);

            if (user != null) {
                JOptionPane.showMessageDialog(this, "Welcome, " + user.getUsername() + "!");
                dispose();   // closes the login window
                new MainFrame().setVisible(true);   // opens the main app (next step)
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}