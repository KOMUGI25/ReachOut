package reachout.ui;

import reachout.dao.DonorDAO;
import reachout.dao.ResourceDAO;
import reachout.model.Donor;
import reachout.model.Resource;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class DonorPanel extends JPanel {

    private final DonorDAO donorDAO = new DonorDAO();
    private final ResourceDAO resourceDAO = new ResourceDAO();

    private DefaultTableModel donorTableModel;
    private DefaultTableModel resourceTableModel;
    private JTable donorTable;
    private JComboBox<String> donorTypeBox;
    private JComboBox<Integer> donorIdBoxForResource;

    public DonorPanel() {
        setLayout(new GridLayout(2, 1, 0, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(buildDonorSection());
        add(buildResourceSection());

        refreshDonorTable();
        refreshResourceTable();
    }

    // ---------------- DONOR SECTION ----------------
    private JPanel buildDonorSection() {
        JPanel section = new JPanel(new BorderLayout(10, 10));
        section.setBorder(BorderFactory.createTitledBorder("Donors"));

        // Form
        JPanel form = new JPanel(new GridLayout(1, 9, 5, 5));
        JTextField nameField = new JTextField();
        donorTypeBox = new JComboBox<>(new String[]{"INDIVIDUAL", "NGO", "BUSINESS"});
        JTextField contactField = new JTextField();
        JTextField locationField = new JTextField();
        JButton addButton = new JButton("Add Donor");

        form.add(new JLabel("Name:"));
        form.add(nameField);
        form.add(new JLabel("Type:"));
        form.add(donorTypeBox);
        form.add(new JLabel("Contact:"));
        form.add(contactField);
        form.add(new JLabel("Location:"));
        form.add(locationField);
        form.add(addButton);

        addButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String contact = contactField.getText().trim();
            String location = locationField.getText().trim();

            if (name.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name and Location are required.", "Missing info", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                donorDAO.addDonor(new Donor(0, name, (String) donorTypeBox.getSelectedItem(), contact, location));
                nameField.setText("");
                contactField.setText("");
                locationField.setText("");
                refreshDonorTable();
                JOptionPane.showMessageDialog(this, "Donor added successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Table
        donorTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Type", "Contact", "Location"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        donorTable = new JTable(donorTableModel);
        JScrollPane scrollPane = new JScrollPane(donorTable);

        section.add(form, BorderLayout.NORTH);
        section.add(scrollPane, BorderLayout.CENTER);
        return section;
    }

    // ---------------- RESOURCE SECTION ----------------
    private JPanel buildResourceSection() {
        JPanel section = new JPanel(new BorderLayout(10, 10));
        section.setBorder(BorderFactory.createTitledBorder("Resources"));

        JPanel form = new JPanel(new GridLayout(1, 9, 5, 5));
        donorIdBoxForResource = new JComboBox<>();
        JTextField itemField = new JTextField();
        JTextField qtyField = new JTextField();
        JTextField locField = new JTextField();
        JButton addButton = new JButton("Add Resource");

        form.add(new JLabel("Donor ID:"));
        form.add(donorIdBoxForResource);
        form.add(new JLabel("Item:"));
        form.add(itemField);
        form.add(new JLabel("Qty:"));
        form.add(qtyField);
        form.add(new JLabel("Location:"));
        form.add(locField);
        form.add(addButton);

        addButton.addActionListener(e -> {
            if (donorIdBoxForResource.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Add a donor first.", "No donor selected", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                int donorId = (Integer) donorIdBoxForResource.getSelectedItem();
                String item = itemField.getText().trim();
                int qty = Integer.parseInt(qtyField.getText().trim());
                String loc = locField.getText().trim();

                if (item.isEmpty() || loc.isEmpty() || qty <= 0) {
                    JOptionPane.showMessageDialog(this, "Enter a valid item, quantity (>0), and location.", "Missing info", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                resourceDAO.addResource(new Resource(0, donorId, item, qty, loc, "AVAILABLE"));
                itemField.setText("");
                qtyField.setText("");
                locField.setText("");
                refreshResourceTable();
                JOptionPane.showMessageDialog(this, "Resource added successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Quantity must be a number.", "Invalid input", JOptionPane.WARNING_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        resourceTableModel = new DefaultTableModel(new String[]{"ID", "Donor ID", "Item", "Qty", "Location", "Status"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        JTable resourceTable = new JTable(resourceTableModel);
        JScrollPane scrollPane = new JScrollPane(resourceTable);

        section.add(form, BorderLayout.NORTH);
        section.add(scrollPane, BorderLayout.CENTER);
        return section;
    }

    // ---------------- REFRESH HELPERS ----------------
    private void refreshDonorTable() {
        try {
            donorTableModel.setRowCount(0);
            donorIdBoxForResource.removeAllItems();
            List<Donor> donors = donorDAO.getAllDonors();
            for (Donor d : donors) {
                donorTableModel.addRow(new Object[]{d.getDonorId(), d.getName(), d.getType(), d.getContact(), d.getLocation()});
                donorIdBoxForResource.addItem(d.getDonorId());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load donors: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshResourceTable() {
        try {
            resourceTableModel.setRowCount(0);
            List<Resource> resources = resourceDAO.getAllResources();
            for (Resource r : resources) {
                resourceTableModel.addRow(new Object[]{r.getResourceId(), r.getDonorId(), r.getItemName(), r.getQuantity(), r.getLocation(), r.getStatus()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load resources: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}