package reachout.ui;

import reachout.dao.RequestDAO;
import reachout.dao.ResourceDAO;
import reachout.dao.VolunteerDAO;
import reachout.model.Request;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class TrackingPanel extends JPanel {

    private static final String[] STATUS_FLOW = {"PENDING", "MATCHED", "ASSIGNED", "IN_TRANSIT", "DELIVERED"};

    private final RequestDAO requestDAO = new RequestDAO();
    private final ResourceDAO resourceDAO = new ResourceDAO();
    private final VolunteerDAO volunteerDAO = new VolunteerDAO();

    private DefaultTableModel tableModel;
    private JLabel totalsLabel;

    public TrackingPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(buildTable(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        refreshTable();
    }

    private JScrollPane buildTable() {
        tableModel = new DefaultTableModel(
                new String[]{"ID", "Requester", "Item", "Status", "Resource", "Volunteer"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        JTable table = new JTable(tableModel);
        return new JScrollPane(table);
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout(10, 10));

        JPanel advancePanel = new JPanel(new GridLayout(1, 4, 5, 5));
        JTextField requestIdField = new JTextField();
        JButton advanceButton = new JButton("Advance Status →");
        JButton refreshButton = new JButton("Refresh");

        advancePanel.add(new JLabel("Request ID:"));
        advancePanel.add(requestIdField);
        advancePanel.add(advanceButton);
        advancePanel.add(refreshButton);

        totalsLabel = new JLabel();
        totalsLabel.setFont(totalsLabel.getFont().deriveFont(Font.BOLD, 14f));

        advanceButton.addActionListener(e -> {
            try {
                int requestId = Integer.parseInt(requestIdField.getText().trim());
                advanceStatus(requestId);
                requestIdField.setText("");
                refreshTable();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter a valid Request ID.", "Invalid input", JOptionPane.WARNING_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        refreshButton.addActionListener(e -> refreshTable());

        footer.add(advancePanel, BorderLayout.NORTH);
        footer.add(totalsLabel, BorderLayout.SOUTH);
        return footer;
    }

    // Moves a request to the next status in STATUS_FLOW. Awards a volunteer credit on DELIVERED.
    private void advanceStatus(int requestId) throws SQLException {
        List<Request> all = requestDAO.getAllRequests();
        Request target = all.stream().filter(r -> r.getRequestId() == requestId).findFirst().orElse(null);

        if (target == null) {
            JOptionPane.showMessageDialog(this, "No request found with that ID.", "Not found", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (target.getMatchedResourceId() == null || target.getAssignedVolunteerId() == null) {
            JOptionPane.showMessageDialog(this,
                    "This request has no matched resource/volunteer yet, so it can't be tracked. " +
                            "Try raising a request for an item that currently has an AVAILABLE resource.",
                    "Not yet matched", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int currentIndex = java.util.Arrays.asList(STATUS_FLOW).indexOf(target.getStatus());
        if (currentIndex < 0 || currentIndex >= STATUS_FLOW.length - 1) {
            JOptionPane.showMessageDialog(this, "This request is already at its final status.", "No change", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String nextStatus = STATUS_FLOW[currentIndex + 1];
        requestDAO.updateStatus(requestId, nextStatus);

        if (nextStatus.equals("DELIVERED")) {
            if (target.getMatchedResourceId() != null) {
                resourceDAO.updateResourceStatus(target.getMatchedResourceId(), "DELIVERED");
            }
            if (target.getAssignedVolunteerId() != null) {
                volunteerDAO.addCredits(target.getAssignedVolunteerId(), 1);
                volunteerDAO.setAvailability(target.getAssignedVolunteerId(), true);
            }
            JOptionPane.showMessageDialog(this, "Delivered! Volunteer credited +1 point.");
        }
    }

    private void refreshTable() {
        try {
            tableModel.setRowCount(0);
            List<Request> requests = requestDAO.getAllRequests();
            int delivered = 0;
            for (Request r : requests) {
                tableModel.addRow(new Object[]{
                        r.getRequestId(), r.getRequesterName(), r.getItemNeeded(), r.getStatus(),
                        r.getMatchedResourceId() != null ? r.getMatchedResourceId() : "-",
                        r.getAssignedVolunteerId() != null ? r.getAssignedVolunteerId() : "-"
                });
                if ("DELIVERED".equals(r.getStatus())) delivered++;
            }
            totalsLabel.setText("Total Requests: " + requests.size() + "   |   Delivered: " + delivered);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load requests: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}