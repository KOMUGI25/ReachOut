package reachout;

import com.formdev.flatlaf.FlatLightLaf;
import reachout.ui.LoginPanel;

public class Main {
    public static void main(String[] args) {
        FlatLightLaf.setup();   // modern flat theme, applied before any window is created
        new LoginPanel().setVisible(true);
    }
}