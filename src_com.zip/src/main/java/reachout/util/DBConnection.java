package reachout.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Single shared point for opening a connection to the ReachOut MySQL database.
 * Every DAO class (DonorDAO, ResourceDAO, etc.) will call getConnection() from here
 * instead of each writing its own connection code — this is Phase B's foundation.
 */
public class DBConnection {

    // Change YOUR_PASSWORD to your actual local MySQL root password.
    // Keep this file on your own machine only — never commit real passwords to a
    // shared/public GitHub repo.
    private static final String URL = "jdbc:mysql://localhost:3306/reachout";
    private static final String USER = "root";
    private static final String PASSWORD = "kom@mysql26";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}