package reachout.dao;

import reachout.model.*;

public class TestAllDAOs {
    public static void main(String[] args) {
        try {
            // Login test — using the seed admin from schema.sql
            UserDAO userDAO = new UserDAO();
            User loggedIn = userDAO.validateLogin("admin", "admin123");
            System.out.println("Login test: " + (loggedIn != null ? "SUCCESS as " + loggedIn.getRole() : "FAILED"));

            // Add a resource for the donor we created earlier (donor_id = 1)
            ResourceDAO resourceDAO = new ResourceDAO();
            int resId = resourceDAO.addResource(new Resource(0, 1, "Rice Bags", 50, "Chennai", "AVAILABLE"));
            System.out.println("Added resource with ID: " + resId);

            // Add a volunteer
            VolunteerDAO volunteerDAO = new VolunteerDAO();
            int volId = volunteerDAO.addVolunteer(new Volunteer(0, "Arjun", "9998887777", "Chennai", true, 0));
            System.out.println("Added volunteer with ID: " + volId);

            // Raise a request
            RequestDAO requestDAO = new RequestDAO();
            int reqId = requestDAO.addRequest(new Request(0, "Flood Relief Camp", "Rice Bags", "Chennai", "PENDING", null, null));
            System.out.println("Added request with ID: " + reqId);

            // Manually assign the match (this is what MatchingService will automate next)
            boolean assigned = requestDAO.assignMatch(reqId, resId, volId);
            System.out.println("Match assigned: " + assigned);

            // Print all requests to confirm
            System.out.println("All requests:");
            for (Request r : requestDAO.getAllRequests()) {
                System.out.println("  Request #" + r.getRequestId() + " - " + r.getItemNeeded()
                        + " - status: " + r.getStatus()
                        + " - resource: " + r.getMatchedResourceId()
                        + " - volunteer: " + r.getAssignedVolunteerId());
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}