package reachout.dao;

import reachout.model.Donor;
import java.util.List;

public class TestDonorDAO {
    public static void main(String[] args) {
        DonorDAO donorDAO = new DonorDAO();
        try {
            // Add a test donor
            Donor newDonor = new Donor(0, "Subhavi", "INDIVIDUAL", "9876543210", "Chennai");
            int newId = donorDAO.addDonor(newDonor);
            System.out.println("Added donor with ID: " + newId);

            // List all donors
            List<Donor> donors = donorDAO.getAllDonors();
            System.out.println("All donors:");
            for (Donor d : donors) {
                System.out.println(d);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}